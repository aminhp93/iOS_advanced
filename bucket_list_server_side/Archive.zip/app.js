var express = require("express")
var app = express()
var bodyParser = require('body-parser');

var tasks = [{ "objective": "Task 1", "created_at": "Time 1" }, { "objective": "Task 2", "created_at": "Time 2" }]

app.use(bodyParser.urlencoded({ extended: true }));
// app.use(bodyParser.json());

app.get("/tasks", function(request, response) {
    response.json({ "results": tasks })
})

app.post("/tasks", function(request, response) {
    console.log(request.body.objective, "===============12")
    tasks += [{ "objective": request.body.objective, "created_at": new Date().toUTCString() }]

})

app.listen(3000)
